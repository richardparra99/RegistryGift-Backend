from django.test import TestCase
from django.contrib.auth.models import User
from registry.models.event import Event
from datetime import datetime

class EventoModelTest(TestCase):
    def test_crear_evento(self):
        user = User.objects.create_user(username="juan", password="1234")
        evento = Event.objects.create(
            owner=user,
            name="Cumpleaños de Ana",
            description="Fiesta sorpresa en el jardín",
            datetime=datetime(2025, 8, 20, 18, 0)
        )
        self.assertEqual(evento.name, "Cumpleaños de Ana")
        self.assertEqual(evento.description, "Fiesta sorpresa en el jardín")
        self.assertEqual(str(evento.datetime.date()), "2025-08-20")
        self.assertEqual(str(evento), "Cumpleaños de Ana (birthday)")
